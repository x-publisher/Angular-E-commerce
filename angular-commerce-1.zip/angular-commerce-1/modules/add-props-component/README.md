# Add properties component

Form to add new categories, attributes, tags

Depends on DAL and ProductService