# Session Flow

## Track some user actions: 
1. Set device Id
2. Set session Id
3. Track visited routes of user
4. Track user clicks
5. Detect mobile device