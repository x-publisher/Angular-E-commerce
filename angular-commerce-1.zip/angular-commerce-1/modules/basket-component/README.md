# Basket component

Display user basket