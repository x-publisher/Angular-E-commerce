export { CategoriesComponent } from './src/categories.component';
export { CategoriesModule } from './src/categories.module';