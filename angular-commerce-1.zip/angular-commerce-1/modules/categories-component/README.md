# Categories component

Component that display available Categories

Depends on Product service