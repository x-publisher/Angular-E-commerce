export {SearchBarModule} from './src/search-bar.module';
export { SearchBarComponent } from './src/search-bar.component';