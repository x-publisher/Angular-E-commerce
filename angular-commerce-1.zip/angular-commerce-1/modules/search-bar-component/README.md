# Search Bar Component

Live search input for products

Depends on Product Service