# Products list component

Displays product from specific category