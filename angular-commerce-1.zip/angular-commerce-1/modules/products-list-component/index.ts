export { ProductsListModule } from './src/products-list.module';
export { ProductsListComponent } from './src/products-list.component';