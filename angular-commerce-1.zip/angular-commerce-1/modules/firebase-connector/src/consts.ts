/**
 * ElasticSearch index of database
 */
export let esIndex = "firebase";
