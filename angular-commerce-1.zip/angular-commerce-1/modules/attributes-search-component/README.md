# Attributes search component

Generate attrribute filter component that integrates into Product List Component

Depends on DAL and ProductService