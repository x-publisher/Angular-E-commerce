export { AttributesSearchModule } from './src/attributes-search.module';
export { AttributesSearchComponent } from './src/attributes-search.component';