export { ProductComponent } from './src/product.component';
export { ProductModule } from './src/product.module';
