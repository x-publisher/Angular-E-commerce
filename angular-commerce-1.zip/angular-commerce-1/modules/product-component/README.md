# Product component

Display product by ID from REST route