# Tags Search Component

Generate tags filter that integrate into Product List Component

Depends on DAL and Product Service