export { TagsSearchModule } from './src/tags-search.module';
export { TagsSearchComponent } from './src/tags-search.component';