# Add product component

Form to add new product

Depends on ProductService, DAL