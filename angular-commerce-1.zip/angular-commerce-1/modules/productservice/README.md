# Product service

Service that send work to DAL related to products (search, filted, get categories, attributes, tags etc.)