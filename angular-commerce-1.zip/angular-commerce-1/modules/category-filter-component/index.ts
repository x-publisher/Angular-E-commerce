export { CategoryFilterModule } from './src/category-filter.module';
