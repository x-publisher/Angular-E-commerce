# Category filter component
Gets child categories from some general category and emits selected category to the top. This component is integrated into product general component.