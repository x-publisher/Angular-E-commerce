export { LoadingIndicatorModule } from './src/loading-indicator.module';
export { LoadingPage, LoadingIndicator} from './src/loading-indicator';