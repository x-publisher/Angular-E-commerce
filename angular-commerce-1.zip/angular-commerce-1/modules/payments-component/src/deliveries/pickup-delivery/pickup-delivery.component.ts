import { Component } from '@angular/core';

/**
 * Pickup delivery component. (Not realize yet)
 */
@Component({
    selector: 'pickup-delivery',
    templateUrl: './pickup-delivery.component.html',
    styleUrls: ['pickup-delivery.component.scss']
})
export class PickupDeliveryComponent {
    
}