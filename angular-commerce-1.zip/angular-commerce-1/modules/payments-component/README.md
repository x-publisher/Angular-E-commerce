# Payments component

Available payments: 
* 2Checkout
    