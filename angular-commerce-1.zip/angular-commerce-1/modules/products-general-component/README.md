# Products general component
Shows products from child categories of some general category