export { ProductsGeneralModule } from './src/products-general.module';
export { ProductsGeneralComponent } from './src/products-general.component';