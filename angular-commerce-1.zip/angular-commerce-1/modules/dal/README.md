# Data abstraction layer
Bridge for database connector(for now only Firebase).

Depends on some angular2 connector module(For now FirebaseConnectorModule)
