# SEO text component

`SEO text component` display SEO text block from specific url. User have to input current `url` and optional index of text in `blocks` array.

For example:
```html
<seo-text [url]="router.url" [indexBlock]="1"></seo-text>
```