export { SeoTextModule } from './src/seo-text.module';
export { SeoTextComponent } from './src/seo-text.component';
