# General categories all

Show all products from some general category or from specific child category from general category.
This component is integrated into `Product general component`

//TODO change name
