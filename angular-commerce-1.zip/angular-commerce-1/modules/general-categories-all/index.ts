export { GeneralCategoryAllModule } from './src/general-category-all.module';
export { GeneralCategoryAllComponent } from './src/general-category-all.component';
